# app.py
from flask import Flask, render_template, request
from models import UserData
import config

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    username = request.form['username']
    password = request.form['password']
    user_data = UserData(username, password)
    print(f"\nПолучены данные:")
    print(user_data)
    print("-" * 40)
    return '<h2>Данные успешно отправлены!</h2><p>Проверьте терминал.</p>'

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=config.PORT, debug=config.DEBUG)