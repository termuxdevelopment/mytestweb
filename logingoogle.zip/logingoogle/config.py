# config.py
PORT = 8000
DEBUG = True