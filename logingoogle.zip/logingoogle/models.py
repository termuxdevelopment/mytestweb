# models.py
class UserData:
    def __init__(self, username, password):
        self.username = username
        self.password = password

    def __str__(self):
        return f"Телефон/почта: {self.username}, Пароль: {self.password}"