# app.py
from flask import Flask, render_template, request
from models import UserData
import config

app = Flask(__name__, template_folder='templates', static_folder='static')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    username = request.form['username']
    password = request.form['password']
    user_data = UserData(username, password)
    print(f"\n[{config.PORT}] Получены данные:")
    print(user_data)
    print("-" * 40)
    return '<h2>Вы добавлены в список сервера</h2><p>Ожидайте дальнейщих команд оператора.</p>'

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=config.PORT, debug=config.DEBUG)