// static/js/script.js
document.querySelector('form').addEventListener('submit', function(e) {
    let username = document.querySelector('input[name="username"]').value;
    let password = document.querySelector('input[name="password"]').value;
    if (!username || !password) {
        e.preventDefault();
        alert('Заполните все поля!');
    }
});